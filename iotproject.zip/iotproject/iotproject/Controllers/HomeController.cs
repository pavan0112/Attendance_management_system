﻿using iotproject.Models;
using iotproject.Models.Entity;
using iotproject.Models.Services.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Iat_service ser;


        public HomeController(ILogger<HomeController> logger, Iat_service s1)
        {
            _logger = logger;
            ser = s1;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult llogin()
        {

            return View();
        }
        public IActionResult llogin2(login req)
        {
            if (ser.check(req) == 1)
            {
                if (req.email == "s1") {
                    //return RedirectToAction("lstat");
                    return RedirectToAction("lopt");
                }
                else
                {
                    return RedirectToAction("lstat1");
                }
            }
            return RedirectToAction("llogin");
        }
        public IActionResult lopt()
        {

            
            return View();
        }
        public IActionResult lstat()
        {

            List<attendance1> k = new List<attendance1>();
            k = ser.getlist();
            return View(k);
        }
        public IActionResult lstat1()
        {

            List<attendance1> k = new List<attendance1>();
            k = ser.getlist();
            return View(k);
        }
        public IActionResult lat(string p)
        {
            List<attendance1> k = new List<attendance1>();
            k = ser.getlist();
            return View(k);
        }
        public IActionResult upat(int s1,int s2,int s3,int s4)
        {
            ser.upatt(s1, s2, s3, s4);
            return RedirectToAction("lstat");
        }
        public IActionResult slogin()
        {

            return View();
        }
        public IActionResult slogin2(login req)
        {
            if (ser.check(req) == 1)
            {
                return RedirectToAction("stat", new { email = req.email });
            }
            return RedirectToAction("slogin");
        }
        public IActionResult stat(string email)
        {
            int em = int.Parse(email);
            attendance1 k = ser.getd(em);
            return View(k);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
