﻿
using iotproject.Models.Entity;
using iotproject.Models.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Repository.repo
{
    public class at_repo : Iat_repo
    {
        private readonly MyDBContext context;
        public at_repo(MyDBContext c)
        {
            context = c;
        }

        public int check(login req)
        {
            login s = new login();
            
            
            try
            {
                s = context.logins.Where(a => a.email == req.email).FirstOrDefault();

                if (s.password == req.password)
                {
                    return 1;
                }
            }
            catch (Exception e)
            {

            }

            return 0;
        }
        public attendance1 getd(int em)
        {
            attendance1 s = new attendance1();

            try
            {
                s = context.attendance1s.Where(a => a.roll_no == em).FirstOrDefault();

            }
            catch (Exception e)
            {

            }

            return s;
        }
        public int upatt(int a, int b,int c, int d)
        {
            List<attendance1> s = new List<attendance1>();

            try
            {
                s = context.attendance1s.Where(a => a.isDeleted == false).ToList();
                s[0].s1 += a;
                s[1].s1 += b;
                s[2].s1 += c;
                s[3].s1 += d;

                s[0].s1t += 1;
                s[1].s1t += 1;
                s[2].s1t += 1;
                s[3].s1t += 1;

                for(int i = 0; i < 4; i++)
                {
                    attendance1 k= context.attendance1s.Where(a => a.ID==i+1).FirstOrDefault();
                    context.Entry(k).CurrentValues.SetValues(s[i]);
                    context.SaveChanges();
                }
                return 1;

            }
            catch (Exception e)
            {

            }

            return 0;
        }
        public List<attendance1> getlist()
        {
            List<attendance1> s = new List<attendance1>();

            try
            {
                s = context.attendance1s.Where(a => a.isDeleted == false).ToList();

            }
            catch (Exception e)
            {

            }

            return s;
        }
    }
}
