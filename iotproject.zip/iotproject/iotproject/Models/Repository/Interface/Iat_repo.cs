﻿using iotproject.Models.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Repository.Interface
{
    public interface Iat_repo
{
        public int check(login req);
        public attendance1 getd(int em);
        public List<attendance1> getlist();
        public int upatt(int a, int b, int c, int d);
}
}
