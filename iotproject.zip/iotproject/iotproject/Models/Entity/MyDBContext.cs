﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Entity
{
    public class MyDBContext : DbContext
    {
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {


        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<attendance1>().ToTable("attendance1");
            modelBuilder.Entity<login>().ToTable("login");
            
        }
        public DbSet<attendance1> attendance1s { get; set; }
        public DbSet<login> logins { get; set; }
       

    }
}
