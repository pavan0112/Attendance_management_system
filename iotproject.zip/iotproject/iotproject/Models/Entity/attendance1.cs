﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Entity
{
    public class attendance1
    {
        [Key]
        public int ID { set; get; }
        public string name { set; get; }
        public string class_ { get; set; }
        public int roll_no { get; set; }
        public int s1 { get; set; }
        public int s1t { get; set; }
        public int s2 { get; set; }
        public int s2t { get; set; }
        public bool isDeleted { get; set; }
    }
}
