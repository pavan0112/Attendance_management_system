﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Entity
{
    public class login
    {
        [Key]
        public int ID { set; get; }
        public string email { get; set; }
        public string password { get; set; }
        public bool isDeleted { get; set; }
    }
}
