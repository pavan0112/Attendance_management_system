﻿using iotproject.Models.Entity;
using iotproject.Models.Repository.Interface;
using iotproject.Models.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iotproject.Models.Services.service
{
    public class at_service : Iat_service
    {
        private readonly Iat_repo trepo;
        public at_service(Iat_repo a)
        {
            trepo = a;

        }
        public int check(login req)
        {
            return trepo.check(req);
        }
        public attendance1 getd(int em)
        {
            return trepo.getd(em);
        }
        public List<attendance1> getlist()
        {
            return trepo.getlist();
        }
        public int upatt(int a, int b, int c, int d)
        {
            return trepo.upatt(a, b, c, d);
        }
    }
}
